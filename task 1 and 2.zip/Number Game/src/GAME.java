import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Color;

public class GAME extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtarea;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GAME frame = new GAME();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public GAME() {
		setTitle("NUMBER GAME");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 296, 240);
		contentPane = new JPanel();
		contentPane.setBackground(Color.PINK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("");
		label.setFont(new Font("Tahoma", Font.PLAIN, 16));
		label.setBounds(64, 152, 161, 38);
		contentPane.add(label);
		
		txtarea = new JTextField();
		txtarea.setBackground(Color.WHITE);
		txtarea.setFont(new Font("Tahoma", Font.PLAIN, 18));
		txtarea.setBounds(10, 11, 254, 87);
		contentPane.add(txtarea);
		txtarea.setColumns(10);
		
		JButton btn = new JButton("GUESS");
		btn.setBackground(Color.MAGENTA);
		btn.setBounds(74, 109, 131, 32);
		contentPane.add(btn);
	}
}
