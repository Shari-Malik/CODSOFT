import java.util.Random;
import java.util.Scanner;
public class NumberGame {
	
	private static final Random random=new Random();
	
	private static int randomnumber;
	private static int userGuess;
	
	public static void main(String[] args) {
		
		randomnumber = random.nextInt(100) + 1;
		
		while (true) {
			Scanner scanner = new Scanner(System.in);
		
		System.out.print("Guess a Number between 1 and 100: ");
		userGuess = scanner.nextInt();
		
		if(userGuess == randomnumber ) {
			System.out.println ("CORRECT");
			break;
			
		}
		else if(userGuess<randomnumber ) {
			System.out.println("TOO LOW");
		}
		else if (userGuess>randomnumber ) {
			System.out.println ("TOO HIGH");
		}
		
			
		}	
		

	}

}
