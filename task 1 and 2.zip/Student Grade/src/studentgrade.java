import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.BevelBorder;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class studentgrade {

	private JFrame frame;
	private JTextField txtnum1;
	private JTextField txtnum2;
	private JTextField txtnum3;
	private JTextField txttot;
	private JTextField txtavg;
	private JTextField txtgrade;
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					studentgrade window = new studentgrade();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public studentgrade() {
		initialize();
	}

	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.GRAY);
		frame.setBounds(100, 100, 545, 394);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.LIGHT_GRAY);
		panel.setBorder(new BevelBorder(BevelBorder.LOWERED, Color.GRAY, null, null, null));
		panel.setBounds(31, 26, 460, 306);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		txtnum1 = new JTextField();
		txtnum1.setBounds(200, 54, 130, 25);
		panel.add(txtnum1);
		txtnum1.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("MARKS 1");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel.setBounds(115, 53, 113, 25);
		panel.add(lblNewLabel);		
		JLabel lblNewLabel_1 = new JLabel("MARKS 2");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1.setBounds(115, 94, 62, 15);
		panel.add(lblNewLabel_1);	
		JLabel lblNewLabel_1_1 = new JLabel("MARKS 3");
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1_1.setBounds(115, 125, 62, 25);
		panel.add(lblNewLabel_1_1);
		
		txtnum2 = new JTextField();
		txtnum2.setColumns(10);
		txtnum2.setBounds(200, 90, 130, 25);
		panel.add(txtnum2);		
		txtnum3 = new JTextField();
		txtnum3.setColumns(10);
		txtnum3.setBounds(200, 126, 130, 25);
		panel.add(txtnum3);
		txttot = new JTextField();
		txttot.setColumns(10);
		txttot.setBounds(200, 184, 130, 25);
		panel.add(txttot);		
		txtavg = new JTextField();
		txtavg.setColumns(10);
		txtavg.setBounds(200, 220, 130, 25);
		panel.add(txtavg);		
		txtgrade = new JTextField();
		txtgrade.setColumns(10);
		txtgrade.setBounds(200, 256, 130, 25);
		panel.add(txtgrade);
		
		JLabel lbltoatal = new JLabel("TOTAL");
		lbltoatal.setFont(new Font("Tahoma", Font.BOLD, 12));
		lbltoatal.setBounds(128, 183, 62, 25);
		panel.add(lbltoatal);		
		JLabel lblaverage = new JLabel("AVERAGE %");
		lblaverage.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblaverage.setBounds(115, 214, 91, 35);
		panel.add(lblaverage);		
		JLabel lblgrade = new JLabel("GRADE");
		lblgrade.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblgrade.setBounds(128, 255, 62, 25);
		panel.add(lblgrade);
		
		JButton btnNewButton = new JButton("ADD");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 
			int m1 = Integer.parseInt(txtnum1.getText());
			int m2 = Integer.parseInt(txtnum2.getText());
			int m3 = Integer.parseInt(txtnum3.getText());
			int tot = m1+m2+m3;
			
			double avg = tot/3;
			
			txttot.setText(String.valueOf(tot));
			txtavg.setText(String.valueOf(avg));
			
			if(avg>30)
			{
				txtgrade.setText("PASS");
			}
			else 
			{
				txtgrade.setText("FAIL");
			}
				
			}
		});
		btnNewButton.setBounds(357, 73, 78, 25);
		panel.add(btnNewButton);
		
		JButton btnClear = new JButton("CLEAR");
		btnClear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				txtnum1.setText("");
				txtnum2.setText("");
				txtnum3.setText("");
				txttot.setText("");
				txtavg.setText("");
				txtgrade.setText("");
				txtnum1.requestFocus();
				
				
				
			}
		});
		btnClear.setBounds(357, 109, 78, 25);
		panel.add(btnClear);
		
		JButton btnExit = new JButton("EXIT");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				System.exit(0);
			}
		});
		btnExit.setBounds(357, 256, 78, 24);
		panel.add(btnExit);
		
		JLabel lblStudentGradeCalculator = new JLabel("STUDENT  GRADE CALCULATOR");
		lblStudentGradeCalculator.setForeground(Color.BLACK);
		lblStudentGradeCalculator.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblStudentGradeCalculator.setBounds(115, 18, 297, 25);
		panel.add(lblStudentGradeCalculator);
	}
}
